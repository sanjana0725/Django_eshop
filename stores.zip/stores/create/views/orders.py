from django.shortcuts import render, redirect
from django.contrib.auth.hashers import check_password

from create.abc.customer import Customer
from django.views import View
from create.abc.product import Product
from create.abc.orders import Order
from create.middlewares.auth import auth_middleware


class OrderView(View):



    def get(self, request):
        customer = request.session.get('customer')
        orders = Order.get_orders_by_customer(customer)
        print(orders)


        return render(request,'orders.html', {'orders': orders})

